package com.pankaj.jarvis

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Cyan = Color(0xFF54DFFF)
private val Dark = Color(0xFF030914)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JarvisScreen() }
    }
}

@Composable
fun JarvisScreen() {
    var command by remember { mutableStateOf("") }
    var response by remember { mutableStateOf("नमस्ते पंकज। JARVIS का Android प्रारंभिक संस्करण तैयार है।") }

    MaterialTheme {
        Box(
            modifier = Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF103B5A), Color(0xFF061426), Dark))
            )
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Spacer(Modifier.height(16.dp))
                Text("STARK-STYLE PERSONAL AI", color = Cyan, fontSize = 11.sp, letterSpacing = 3.sp)
                Text("J.A.R.V.I.S.", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold, letterSpacing = 6.sp)
                Box(
                    modifier = Modifier.padding(18.dp).size(190.dp)
                        .background(Color(0xFF0A3854), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.size(150.dp).background(Color(0xFF12648A), CircleShape), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(92.dp).background(
                            Brush.radialGradient(listOf(Color.White, Cyan, Color(0xFF0874A5))),
                            CircleShape
                        ))
                    }
                }
                Text("SYSTEM ONLINE • LOCAL INTERFACE", color = Cyan, fontSize = 12.sp)
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xCC061B2D)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("JARVIS CONSOLE", color = Cyan, fontWeight = FontWeight.Bold)
                        Text(response, color = Color.White, fontSize = 14.sp)
                    }
                }
                OutlinedTextField(
                    value = command,
                    onValueChange = { command = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("अपना आदेश लिखें", color = Cyan) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Cyan,
                        unfocusedBorderColor = Color(0xFF287A9A),
                        cursorColor = Cyan
                    )
                )
                Button(
                    onClick = {
                        response = if (command.isBlank()) {
                            "पंकज, पहले कोई आदेश लिखो।"
                        } else {
                            "तुम्हारा आदेश मिला: \"$command\"। अभी AI कनेक्शन और सुरक्षित फोन-कमांड मॉड्यूल जोड़ना बाकी है।"
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF075477))
                ) { Text("आदेश भेजें", color = Color.White) }
                Text(
                    "BUILD 0.1 • OWNER: PANKAJ",
                    color = Color(0xFF83BBD0),
                    fontSize = 10.sp,
                    letterSpacing = 2.sp
                )
                Text(
                    "यह शुरुआती APK ढाँचा है; अभी AI API, voice और device automation जुड़े नहीं हैं।",
                    color = Color(0xFF9AB8C5),
                    fontSize = 11.sp
                )
            }
        }
    }
}
