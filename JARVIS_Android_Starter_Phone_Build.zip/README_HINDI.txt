JARVIS Android Starter – केवल फोन से APK बनाने के लिए

यह असली Android Studio project का शुरुआती ढाँचा है। अभी इसमें Iron-Man-प्रेरित UI और टेक्स्ट कमांड डेमो है। AI API, voice assistant, lock-screen operation, memory और phone automation अभी शामिल नहीं हैं।

फोन से APK बनाने का तरीका:
1. GitHub पर नया repository बनाएं, जैसे jarvis-android।
2. ZIP extract करके सभी फाइलें/फोल्डर repository की root में upload करें। खास ध्यान: .github/workflows/build-apk.yml भी upload होना चाहिए।
3. GitHub repository में Actions tab खोलें। "Build JARVIS APK" workflow चुनें और Run workflow दबाएँ।
4. Build सफल होने पर workflow run के नीचे Artifacts में JARVIS-debug-APK डाउनलोड करें।
5. ZIP artifact को फोन में extract करें। app-debug.apk पर टैप करके install करें। Android पूछे तो केवल अपने डाउनलोड किए हुए APK के लिए अनुमति दें।

सुरक्षा:
- किसी भी AI provider की API key APK या सार्वजनिक repository में कभी न डालें।
- यह debug APK है, Play Store release APK नहीं।
- लॉक स्क्रीन से लगातार सुनना Android पर सीमित है; इस starter में ऐसा फीचर नहीं है।
